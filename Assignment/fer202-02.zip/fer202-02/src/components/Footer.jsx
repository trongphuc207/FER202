import React from 'react';
import { Container, Carousel } from 'react-bootstrap';

const Footer = () => {

  return (
    <footer
      style={{
        backgroundColor: '#97a4a9ff',
        padding: '20px 0',
        marginTop: 'auto',
      }}
    >
      <Container>
        <div className>
          <div>Manger Expense</div>
          <div >2025 PersonalBudger</div>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;

