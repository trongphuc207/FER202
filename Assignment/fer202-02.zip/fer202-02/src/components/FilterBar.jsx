import React from 'react';
import { Card, Form, Row, Col, Button } from 'react-bootstrap';

const FilterBar = () => {

    
    return (
        <Card className="mb-4 shadow-sm">
            <Card.Body>
                <Form>
                    <Row className="g-3">

                        <Col xs={6} md={4} lg={2}>
                            <Form.Group>
                                <Form.Label>Filter by Category</Form.Label>
                                <Form.Select>
                                    <option value="">All categories</option>
                                    <option value="">Food</option>
                                    <option value="">Utilities</option>
                                    <option value="">Entertainment</option>
                                </Form.Select>
                            </Form.Group>
                        </Col>
                    </Row>
                </Form>
            </Card.Body>
        </Card>
    );
};

export default FilterBar;
