
npm install
npm install bootstrap react-bootstrap 
npm install react-router-dom@6
npm install -g json-server
npm install axios react-icons



json-server --watch db.json --port 3001 